import java.util.HashMap;
import java.util.Scanner;

public class ATMSystem {
    private static HashMap<String, String> userCredentials = new HashMap<>();
    private static HashMap<String, Double> userBalances = new HashMap<>();
    private static HashMap<String, String> transactionHistories = new HashMap<>();

    public static void main(String[] args) {
        // Sample users
        userCredentials.put("user1", "1234");
        userBalances.put("user1", 5000.0);
        transactionHistories.put("user1", "");

        userCredentials.put("user2", "5678");
        userBalances.put("user2", 3000.0);
        transactionHistories.put("user2", "");

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter User ID: ");
        String userId = scanner.nextLine();
        System.out.print("Enter PIN: ");
        String pin = scanner.nextLine();

        if (authenticateUser(userId, pin)) {
            System.out.println("Login Successful!");
            showMenu(userId, scanner);
        } else {
            System.out.println("Invalid User ID or PIN!");
        }

        scanner.close();
    }

    private static boolean authenticateUser(String userId, String pin) {
        return userCredentials.containsKey(userId) && userCredentials.get(userId).equals(pin);
    }

    private static void showMenu(String userId, Scanner scanner) {
        while (true) {
            System.out.println("\nATM Menu:");
            System.out.println("1. Transaction History");
            System.out.println("2. Withdraw");
            System.out.println("3. Deposit");
            System.out.println("4. Transfer");
            System.out.println("5. Quit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    showTransactionHistory(userId);
                    break;
                case 2:
                    withdrawAmount(userId, scanner);
                    break;
                case 3:
                    depositAmount(userId, scanner);
                    break;
                case 4:
                    transferAmount(userId, scanner);
                    break;
                case 5:
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showTransactionHistory(String userId) {
        String history = transactionHistories.get(userId);
        if (history.isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            System.out.println("Transaction History:");
            System.out.println(history);
        }
    }

    private static void withdrawAmount(String userId, Scanner scanner) {
        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        if (amount > 0 && amount <= userBalances.get(userId)) {
            userBalances.put(userId, userBalances.get(userId) - amount);
            transactionHistories.put(userId, transactionHistories.get(userId) + "Withdrawn: " + amount + "\n");
            System.out.println("Withdrawal successful! Remaining balance: " + userBalances.get(userId));
        } else {
            System.out.println("Insufficient balance or invalid amount.");
        }
    }

    private static void depositAmount(String userId, Scanner scanner) {
        System.out.print("Enter amount to deposit: ");
        double amount = scanner.nextDouble();

        if (amount > 0) {
            userBalances.put(userId, userBalances.get(userId) + amount);
            transactionHistories.put(userId, transactionHistories.get(userId) + "Deposited: " + amount + "\n");
            System.out.println("Deposit successful! Total balance: " + userBalances.get(userId));
        } else {
            System.out.println("Invalid amount.");
        }
    }

    private static void transferAmount(String userId, Scanner scanner) {
        System.out.print("Enter recipient User ID: ");
        scanner.nextLine(); // Consume newline
        String recipientId = scanner.nextLine();

        if (!userCredentials.containsKey(recipientId)) {
            System.out.println("Recipient not found!");
            return;
        }

        System.out.print("Enter amount to transfer: ");
        double amount = scanner.nextDouble();

        if (amount > 0 && amount <= userBalances.get(userId)) {
            userBalances.put(userId, userBalances.get(userId) - amount);
            userBalances.put(recipientId, userBalances.get(recipientId) + amount);
            transactionHistories.put(userId, transactionHistories.get(userId) + "Transferred: " + amount + " to " + recipientId + "\n");
            transactionHistories.put(recipientId, transactionHistories.get(recipientId) + "Received: " + amount + " from " + userId + "\n");
            System.out.println("Transfer successful! Remaining balance: " + userBalances.get(userId));
        } else {
            System.out.println("Insufficient balance or invalid amount.");
        }
    }
}